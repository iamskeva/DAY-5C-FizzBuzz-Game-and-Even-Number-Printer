# Python program to print Even Numbers in given range
# total = 0
# for number in range(1, 101):
#   if number % 2 == 0:
#    total += number
# print(total)

# =====================================================================================================================================================+

#The program that automatically prints the solution to the FizzBuzz game.

for number in range(1, 101):
  if number % 3 == 0 and number % 5 == 0:
    number = "FizzBuzz"
  elif number % 3 == 0:
    number = "Fizz"
  elif number % 5 == 0:
    number = "Buzz"
  print(number)